Microchip MCP3002 10-bit ADC 

